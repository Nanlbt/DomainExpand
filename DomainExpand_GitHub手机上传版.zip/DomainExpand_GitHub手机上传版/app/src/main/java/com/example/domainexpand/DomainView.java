package com.example.domainexpand;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public final class DomainView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random(42);
    private long startNs = 0;
    private boolean playing = false;
    private float scale = 1f, ox = 0, oy = 0;
    private int rw, rh;
    private final Ray[] rays = new Ray[120];
    private final Glyph[] glyphs = new Glyph[90];
    private final Star[] stars = new Star[180];

    private static final class Ray { float a,len,w,phase; boolean white; }
    private static final class Glyph { float a,z,speed; char s; }
    private static final class Star { float x,y,s,z,p; }

    public DomainView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.MONOSPACE);
        initParticles();
        setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                start(); return true;
            }
            return true;
        });
    }

    private void initParticles(){
        char[] chars = "01AEFX79/\\×□■∞Ω§".toCharArray();
        for(int i=0;i<rays.length;i++){
            rays[i]=new Ray(); rays[i].a=(float)(rng.nextDouble()*Math.PI*2);
            rays[i].len=.55f+rng.nextFloat()*.7f; rays[i].w=.6f+rng.nextFloat()*1.7f;
            rays[i].phase=rng.nextFloat()*(float)Math.PI*2; rays[i].white=i%5==0;
        }
        for(int i=0;i<glyphs.length;i++){
            glyphs[i]=new Glyph(); glyphs[i].a=rng.nextFloat()*(float)Math.PI*2;
            glyphs[i].z=rng.nextFloat(); glyphs[i].speed=.08f+rng.nextFloat()*.2f;
            glyphs[i].s=chars[rng.nextInt(chars.length)];
        }
        for(int i=0;i<stars.length;i++){
            stars[i]=new Star(); stars[i].x=rng.nextFloat(); stars[i].y=rng.nextFloat();
            stars[i].z=.2f+rng.nextFloat()*.8f; stars[i].s=.5f+rng.nextFloat()*1.5f; stars[i].p=rng.nextFloat()*6.28f;
        }
    }

    private void start(){
        playing=true; startNs=System.nanoTime(); invalidate();
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        float maxW=1280f, maxH=720f;
        float s=Math.min(1f, Math.min(maxW/w, maxH/h));
        scale=s; rw=Math.max(1,Math.round(w*s)); rh=Math.max(1,Math.round(h*s));
        ox=(w-rw/s)*.5f; oy=(h-rh/s)*.5f;
    }

    @Override protected void onDraw(Canvas real){
        super.onDraw(real);
        if(!playing){ drawStart(real); return; }
        float t=(System.nanoTime()-startNs)/1_000_000_000f;
        real.save();
        float sx=getWidth()/(float)rw, sy=getHeight()/(float)rh;
        real.scale(sx,sy);
        drawFrame(real,rw,rh,t);
        real.restore();
        if(t<34f) postInvalidateDelayed(12); else playing=false;
    }

    private void drawStart(Canvas c){
        c.drawColor(Color.BLACK);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(235,14,10,20));
        float cx=getWidth()/2f, cy=getHeight()/2f;
        c.drawCircle(cx,cy,90,p);
        p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(44);
        c.drawText("领域展开",cx,cy+14,p);
        p.setTextSize(18); p.setColor(Color.argb(170,255,255,255));
        c.drawText("点击屏幕开始",cx,cy+54,p);
    }

    private void drawFrame(Canvas c,int w,int h,float t){
        c.drawColor(Color.BLACK);
        if(t<6.0f) intro(c,w,h,t);
        else if(t<19.5f){ rays(c,w,h,t); glyphs(c,w,h,t); ring(c,w,h,t); }
        else if(t<22.2f){ rays(c,w,h,t); glyphs(c,w,h,t); ring(c,w,h,t); blast(c,w,h,t); }
        else { domain(c,w,h,t); ink(c,w,h,t); }
        vignette(c,w,h);
    }

    private void intro(Canvas c,int w,int h,float t){
        p.setShader(new LinearGradient(0,0,0,h,Color.rgb(5,9,18),Color.rgb(15,19,29),Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        p.setColor(Color.rgb(27,35,43)); c.drawRect(0,h*.55f,w,h,p);
        for(int i=0;i<15;i++){
            float x=i*w/15f,bw=w*(.035f+((i*13)%8)/100f),bh=h*(.06f+((i*11)%9)/100f);
            p.setColor(i%3==0?Color.rgb(38,48,57):Color.rgb(30,39,47)); c.drawRect(x,h*.55f-bh,x+bw,h*.55f,p);
        }
        float cx=w*.5f,cy=h*.56f;
        p.setColor(Color.rgb(45,49,62));
        c.drawRect(cx-13,cy-56,cx+13,cy-21,p); c.drawRect(cx-11,cy-20,cx+11,cy+29,p);
        c.drawRect(cx-29,cy-18,cx-12,cy-10,p); c.drawRect(cx+12,cy-18,cx+29,cy-10,p);
        c.drawRect(cx-10,cy+29,cx-2,cy+58,p); c.drawRect(cx+2,cy+29,cx+10,cy+58,p);
        float q=clamp((t-2.5f)/3.5f),e=easeOut(q),r=Math.min(w,h)*(.01f+.28f*e);
        if(q>0){
            p.setShader(new RadialGradient(cx,cy,Math.max(1,r*1.7f),new int[]{Color.WHITE,Color.WHITE,Color.TRANSPARENT},new float[]{0,.38f,1},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r*1.7f,p);p.setShader(null);p.setColor