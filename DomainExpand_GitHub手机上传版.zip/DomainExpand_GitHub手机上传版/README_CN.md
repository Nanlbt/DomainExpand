# 领域展开 Android 原生版

这是一个不依赖 WebView、不播放原视频的 Android 原生 Canvas 动画工程。

## GitHub 手机编译

1. 将本目录中的所有文件上传到 GitHub 仓库根目录（不是把本 ZIP 当作工程文件提交）。
2. 上传完成后打开仓库顶部的 **Actions**。
3. 选择 **Build Android APK**。
4. 点击 **Run workflow**（如果已经因为 push 自动运行，也可以直接等待）。
5. 构建成功后进入该次运行，在 **Artifacts** 下载 `DomainExpand-debug-apk`。
6. 解压 Artifact，即可得到 `app-debug.apk`。

工程要求 JDK 17、Android SDK 35、Gradle 8.9；GitHub Actions 会自动准备这些环境。
