package com.example.domainexpand;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

/**
 * Native Android renderer. No WebView and no source video playback.
 * Designed around a small number of batched Canvas primitives and a capped
 * internal render scale so mid-range phones don't get hammered by 1440x2036 work.
 */
public final class DomainView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random(42);
    private long startNs = 0;
    private boolean playing = false;
    private float scale = 1f, ox = 0, oy = 0;
    private int rw, rh;
    private final Ray[] rays = new Ray[120];
    private final Glyph[] glyphs = new Glyph[90];
    private final Star[] stars = new Star[180];

    private static final class Ray { float a,len,w,phase; boolean white; }
    private static final class Glyph { float a,z,speed; char ch; }
    private static final class Star { float x,y,s,z,p; }

    public DomainView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        text.setTypeface(Typeface.MONOSPACE);
        initParticles();
        setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                start(); return true;
            }
            return true;
        });
    }

    private void initParticles(){
        char[] chars = "01AEFX79/\\×□■∞Ω§".toCharArray();
        for(int i=0;i<rays.length;i++){
            rays[i]=new Ray(); rays[i].a=(float)(rng.nextDouble()*Math.PI*2);
            rays[i].len=.55f+rng.nextFloat()*.7f; rays[i].w=.6f+rng.nextFloat()*1.7f;
            rays[i].phase=rng.nextFloat()*(float)Math.PI*2; rays[i].white=i%5==0;
        }
        for(int i=0;i<glyphs.length;i++){
            glyphs[i]=new Glyph(); glyphs[i].a=rng.nextFloat()*(float)Math.PI*2;
            glyphs[i].z=rng.nextFloat(); glyphs[i].speed=.08f+rng.nextFloat()*.2f;
            glyphs[i].s=chars[rng.nextInt(chars.length)];
        }
        for(int i=0;i<stars.length;i++){
            stars[i]=new Star(); stars[i].x=rng.nextFloat(); stars[i].y=rng.nextFloat();
            stars[i].z=.2f+rng.nextFloat()*.8f; stars[i].s=.5f+rng.nextFloat()*1.5f; stars[i].p=rng.nextFloat()*6.28f;
        }
    }

    private void start(){
        playing=true; startNs=System.nanoTime(); invalidate();
    }

    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        // Cap internal resolution around 1280x720 equivalent; Canvas then scales once.
        float maxW=1280f, maxH=720f;
        float s=Math.min(1f, Math.min(maxW/w, maxH/h));
        scale=s; rw=Math.max(1,Math.round(w*s)); rh=Math.max(1,Math.round(h*s));
        ox=(w-rw/s)*.5f; oy=(h-rh/s)*.5f;
    }

    @Override protected void onDraw(Canvas real){
        super.onDraw(real);
        if(!playing){ drawStart(real); return; }
        float t=(System.nanoTime()-startNs)/1_000_000_000f;
        // Render at capped resolution, then upscale. This is the main anti-stutter measure.
        real.save();
        float sx=getWidth()/(float)rw, sy=getHeight()/(float)rh;
        real.scale(sx,sy);
        drawFrame(real,rw,rh,t);
        real.restore();
        if(t<34f) postInvalidateDelayed(12); else playing=false;
    }

    private void drawStart(Canvas c){
        c.drawColor(Color.BLACK);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(235,14,10,20));
        float cx=getWidth()/2f, cy=getHeight()/2f;
        c.drawCircle(cx,cy,90,p);
        p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(44);
        c.drawText("领域展开",cx,cy+14,p);
        p.setTextSize(18); p.setColor(Color.argb(170,255,255,255));
        c.drawText("点击屏幕开始",cx,cy+54,p);
    }

    private void drawFrame(Canvas c,int w,int h,float t){
        c.drawColor(Color.BLACK);
        if(t<6.0f) intro(c,w,h,t);
        else if(t<19.5f){ rays(c,w,h,t); glyphs(c,w,h,t); ring(c,w,h,t); }
        else if(t<22.2f){ rays(c,w,h,t); glyphs(c,w,h,t); ring(c,w,h,t); blast(c,w,h,t); }
        else { domain(c,w,h,t); ink(c,w,h,t); }
        vignette(c,w,h);
    }

    private void intro(Canvas c,int w,int h,float t){
        p.setShader(new LinearGradient(0,0,0,h,Color.rgb(5,9,18),Color.rgb(15,19,29),Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        p.setColor(Color.rgb(27,35,43)); c.drawRect(0,h*.55f,w,h,p);
        for(int i=0;i<15;i++){
            float x=i*w/15f,bw=w*(.035f+((i*13)%8)/100f),bh=h*(.06f+((i*11)%9)/100f);
            p.setColor(i%3==0?Color.rgb(38,48,57):Color.rgb(30,39,47)); c.drawRect(x,h*.55f-bh,x+bw,h*.55f,p);
        }
        float cx=w*.5f,cy=h*.56f;
        p.setColor(Color.rgb(45,49,62));
        c.drawRect(cx-13,cy-56,cx+13,cy-21,p); c.drawRect(cx-11,cy-20,cx+11,cy+29,p);
        c.drawRect(cx-29,cy-18,cx-12,cy-10,p); c.drawRect(cx+12,cy-18,cx+29,cy-10,p);
        c.drawRect(cx-10,cy+29,cx-2,cy+58,p); c.drawRect(cx+2,cy+29,cx+10,cy+58,p);
        float q=clamp((t-2.5f)/3.5f),e=easeOut(q),r=Math.min(w,h)*(.01f+.28f*e);
        if(q>0){
            p.setShader(new RadialGradient(cx,cy,Math.max(1,r*1.7f),new int[]{Color.WHITE,Color.WHITE,Color.TRANSPARENT},new float[]{0,.38f,1},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r*1.7f,p);p.setShader(null);p.setColor(Color.WHITE);c.drawCircle(cx,cy,r*.72f,p);
        }
    }

    private void rays(Canvas c,int w,int h,float t){
        float q=clamp((t-5.8f)/13f),e=easeOut(q),cx=w*(.5f-.105f*e),cy=h*.56f,max=(float)Math.hypot(w,h)*1.2f;
        p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND);
        Path pink=new Path(),white=new Path();
        for(Ray r:rays){
            float a=r.a+(float)Math.sin(t*r.phase+r.phase)*.002f,len=max*(.25f+.95f*r.len*e);
            Path path=r.white?white:pink; path.moveTo(cx,cy); path.lineTo(cx+(float)Math.cos(a)*len,cy+(float)Math.sin(a)*len);
        }
        p.setStrokeWidth(1.1f+.9f*e);p.setColor(Color.argb(150,255,70,225));c.drawPath(pink,p);
        p.setStrokeWidth(1f+.8f*e);p.setColor(Color.argb(190,255,255,255));c.drawPath(white,p);
        p.setStrokeWidth(2.0f+.8f*e);p.setColor(Color.argb(185,255,210,255));
        for(int i=0;i<12;i++){
            float a=i/12f*(float)Math.PI*2+.16f,len=max*(.55f+.55f*e);
            c.drawLine(cx,cy,cx+(float)Math.cos(a)*len,cy+(float)Math.sin(a)*len,p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void glyphs(Canvas c,int w,int h,float t){
        float q=clamp((t-10.2f)/8.9f),e=easeOut(q); if(e<=0)return;
        float cx=w*(.48f-.1f*e),cy=h*.56f;
        text.setTextAlign(Paint.Align.CENTER);
        for(Glyph g:glyphs){
            float z=(g.z+t*g.speed*.1f)%1f,rr=Math.min(w,h)*(.06f+g.z*.72f)*(.45f+.85f*e);
            float x=cx+(float)Math.cos(g.a+t*.025)*rr,y=cy+(float)Math.sin(g.a+t*.025)*rr*.58f;
            text.setTextSize(10+z*18);text.setColor(Color.argb((int)(255*(1-z)*(.25f+.7f*e)),255,255,255));
            c.drawText(String.valueOf(g.ch),x,y,text);
        }
    }

    private void ring(Canvas c,int w,int h,float t){
        float q=clamp((t-17.2f)/3.1f),e=easeInOut(q);if(e<=0)return;
        float cx=w*.43f,cy=h*.56f,r=Math.min(w,h)*(.025f+.28f*e);
        p.setStyle(Paint.Style.STROKE);
        for(int i=0;i<7;i++){p.setStrokeWidth(1.2f+i*.7f);p.setColor(Color.argb((int)(25+23*(1-i/7f)),255,255,255));c.drawOval(cx-r*(1+i*.08f),cy-r*(.7f+i*.035f),cx+r*(1+i*.08f),cy+r*(.7f+i*.035f),p);}
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx,cy,Math.max(1,r*1.8f),Color.WHITE,Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(cx,cy,r*1.8f,p);p.setShader(null);
    }

    private void blast(Canvas c,int w,int h,float t){
        float q=clamp((t-19.35f)/2.65f),e=easeInOut(q),cx=w*.43f,cy=h*.56f,r=(float)Math.hypot(w,h)*(.025f+1.32f*e);
        p.setShader(new RadialGradient(cx,cy,Math.max(1,r),Color.WHITE,Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
    }

    private void domain(Canvas c,int w,int h,float t){
        float q=clamp((t-20.65f)/4f),e=easeOut(q),cx=w*.43f,cy=h*.56f,max=(float)Math.hypot(w,h)*.9f,rr=max*(.03f+.98f*e);
        // Deep space background
        p.setShader(new RadialGradient(cx,cy,Math.max(1,max*.9f),Color.rgb(8,18,45),Color.BLACK,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
        for(Star st:stars){
            float x=st.x*w+(float)Math.sin(t*.025+st.p)*8,y=st.y*h+(float)Math.cos(t*.018+st.p)*5;
            p.setColor(Color.argb((int)(70+130*st.z),220,235,255));c.drawRect(x,y,x+st.s,y+st.s,p);
        }
        c.save();c.clipPath(circlePath(cx,cy,rr));
        // Accretion disk
        p.setStyle(Paint.Style.STROKE);
        for(int i=0;i<15;i++){float r=Math.min(w,h)*.16f*(1+i*.065f);p.setStrokeWidth(1+(i%3)*.6f);p.setColor(Color.argb(20+(int)(25*(1-i/15f)),190,215,255));c.drawOval(cx-r*2,cy-r*.48f,cx+r*2,cy+r*.48f,p);}
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx,cy,Math.min(w,h)*.35f,new int[]{Color.TRANSPARENT,Color.argb(40,120,170,255),Color.TRANSPARENT},null,Shader.TileMode.CLAMP));c.drawCircle(cx,cy,Math.min(w,h)*.35f,p);p.setShader(null);
        float R=Math.min(w,h)*.16f;
        p.setShader(new RadialGradient(cx,cy,R*.65f,cx,cy,R*2.1f,new int[]{Color.TRANSPARENT,Color.TRANSPARENT,Color.argb(235,255,245,220),Color.argb(120,160,205,255),Color.TRANSPARENT},new float[]{0,.38f,.49f,.58f,1},Shader.TileMode.CLAMP));c.drawCircle(cx,cy,R*2.1f,p);p.setShader(null);
        p.setColor(Color.BLACK);c.drawCircle(cx,cy,R*1.15f,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(R*.12f);p.setColor(Color.argb(45,140,190,255));c.drawLine(cx-R*.7f,cy,cx-w*.35f,cy,p);c.drawLine(cx+R*.7f,cy,cx+w*.35f,cy,p);p.setStyle(Paint.Style.FILL);
        c.restore();
        if(e<1){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f+4*(1-e));p.setColor(Color.argb((int)(170*(1-e)),255,255,255));c.drawCircle(cx,cy,rr,p);p.setStyle(Paint.Style.FILL);}
    }

    private Path circlePath(float x,float y,float r){Path q=new Path();q.addCircle(x,y,r,Path.Direction.CW);return q;}

    private void ink(Canvas c,int w,int h,float t){
        float q=clamp((t-23f)/3.7f);if(q<=0)return;
        for(int i=0;i<16;i++){
            // deterministic pseudo positions, avoiding per-frame object creation
            float x=(.04f+((i*37)%92)/100f)*w,y=(.08f+((i*61)%84)/100f)*h;
            float rr=Math.min(w,h)*(.025f+((i*17)%85)/1000f)*easeOut(clamp(q-(i%5)*.12f));
            p.setColor(Color.argb((int)(130*q),255,255,255));
            c.drawCircle(x,y,rr,p);
            for(int k=0;k<5;k++)c.drawCircle(x+(float)Math.cos(k*1.25+i)*rr*1.5f,y+(float)Math.sin(k*1.25+i)*rr*.7f,rr*.22f,p);
        }
    }

    private void vignette(Canvas c,int w,int h){
        p.setShader(new RadialGradient(w*.48f,h*.5f,Math.min(w,h)*.2f,new int[]{Color.TRANSPARENT,Color.argb(20,0,0,0),Color.argb(190,0,0,0)},new float[]{0,.65f,1},Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);p.setShader(null);
    }

    private static float clamp(float x){return clamp(x,0,1);}
    private static float clamp(float x,float a,float b){return Math.max(a,Math.min(b,x));}
    private static float easeOut(float x){x=clamp(x);return 1-(float)Math.pow(1-x,3);}
    private static float easeInOut(float x){x=clamp(x);return x<.5f?4*x*x*x:1-(float)Math.pow(-2*x+2,3)/2;}
}
